#ifndef LAB3
#define LAB3

int create_pgd(int);

#endif